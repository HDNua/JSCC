# JSCC
JSCC: Developing C Compiler Using JavaScript

  If you clicked the lecture post's link, you should go to here:
  https://github.com/HDNua/JSCC_Lecture.
  This repository is for open source developing.

  This is a project that develops the C programming langauge compiler using JavaScript. This project's license is MIT license so you can use and modify this code freely.
  I'll write how to use this module later.
